export declare class ToolbarModule {
}
