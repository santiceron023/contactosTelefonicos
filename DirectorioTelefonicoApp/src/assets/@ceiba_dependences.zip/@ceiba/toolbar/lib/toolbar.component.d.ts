import { OnInit } from '@angular/core';
export declare class ToolbarComponent implements OnInit {
    constructor();
    ngOnInit(): void;
}
