import { Component, NgModule } from '@angular/core';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var ToolbarComponent = /** @class */ (function () {
    function ToolbarComponent() {
    }
    /**
     * @return {?}
     */
    ToolbarComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    ToolbarComponent.decorators = [
        { type: Component, args: [{
                    selector: 'app-toolbar',
                    template: "<h1>Angular Seed</h1>\r\n<div class=\"more\"></div>\r\n",
                    styles: [":host{background-color:#106cc8;color:rgba(255,255,255,.87);display:block;height:48px;padding:0 16px}h1{display:inline;font-size:20px;font-weight:400;letter-spacing:.1px;line-height:48px}.more{background:url(/assets/svg/more.svg);float:right;height:24px;margin-top:12px;width:24px}"]
                }] }
    ];
    /** @nocollapse */
    ToolbarComponent.ctorParameters = function () { return []; };
    return ToolbarComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var ToolbarModule = /** @class */ (function () {
    function ToolbarModule() {
    }
    ToolbarModule.decorators = [
        { type: NgModule, args: [{
                    declarations: [ToolbarComponent],
                    imports: [],
                    exports: [ToolbarComponent]
                },] }
    ];
    return ToolbarModule;
}());

export { ToolbarComponent, ToolbarModule };
//# sourceMappingURL=ceiba-toolbar.js.map
