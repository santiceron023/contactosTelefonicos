/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/*
 * Public API Surface of navbar
 */
export { NavbarComponent } from './lib/navbar.component';
export { NavbarModule } from './lib/navbar.module';
export { Item } from './lib/modelo/item';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljLWFwaS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0BjZWliYS9uYXZiYXIvIiwic291cmNlcyI6WyJwdWJsaWMtYXBpLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFJQSxnQ0FBYyx3QkFBd0IsQ0FBQztBQUN2Qyw2QkFBYyxxQkFBcUIsQ0FBQztBQUNwQyxxQkFBYyxtQkFBbUIsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBQdWJsaWMgQVBJIFN1cmZhY2Ugb2YgbmF2YmFyXG4gKi9cblxuZXhwb3J0ICogZnJvbSAnLi9saWIvbmF2YmFyLmNvbXBvbmVudCc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9uYXZiYXIubW9kdWxlJztcbmV4cG9ydCAqIGZyb20gJy4vbGliL21vZGVsby9pdGVtJztcbiJdfQ==