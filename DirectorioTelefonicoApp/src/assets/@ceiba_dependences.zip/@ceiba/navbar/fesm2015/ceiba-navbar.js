import { Component, Input, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class NavbarComponent {
    constructor() { }
    /**
     * @return {?}
     */
    ngOnInit() {
    }
}
NavbarComponent.decorators = [
    { type: Component, args: [{
                selector: 'app-navbar',
                template: "<nav>\r\n  <a *ngFor=\"let item of items\" [routerLink]=\"item.url\" routerLinkActive=\"active\">{{item.nombre}}</a>\r\n</nav>",
                styles: [":host{border:0 solid #e1e1e1;border-bottom-width:1px;display:block;height:48px;padding:0 16px}nav a{color:#8f8f8f;font-size:14px;font-weight:500;line-height:48px;margin-right:20px;text-decoration:none;vertical-align:middle;cursor:pointer}nav a.router-link-active{color:#106cc8}"]
            }] }
];
/** @nocollapse */
NavbarComponent.ctorParameters = () => [];
NavbarComponent.propDecorators = {
    items: [{ type: Input }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class NavbarModule {
}
NavbarModule.decorators = [
    { type: NgModule, args: [{
                declarations: [NavbarComponent],
                imports: [BrowserModule, CommonModule, RouterModule
                ],
                exports: [NavbarComponent]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class Item {
}

export { Item, NavbarComponent, NavbarModule };
//# sourceMappingURL=ceiba-navbar.js.map
