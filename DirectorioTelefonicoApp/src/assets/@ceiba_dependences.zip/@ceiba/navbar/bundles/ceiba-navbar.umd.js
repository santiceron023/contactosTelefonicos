(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/platform-browser'), require('@angular/common'), require('@angular/router')) :
    typeof define === 'function' && define.amd ? define('@ceiba/navbar', ['exports', '@angular/core', '@angular/platform-browser', '@angular/common', '@angular/router'], factory) :
    (global = global || self, factory((global.ceiba = global.ceiba || {}, global.ceiba.navbar = {}), global.ng.core, global.ng.platformBrowser, global.ng.common, global.ng.router));
}(this, function (exports, core, platformBrowser, common, router) { 'use strict';

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var NavbarComponent = /** @class */ (function () {
        function NavbarComponent() {
        }
        /**
         * @return {?}
         */
        NavbarComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
        };
        NavbarComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'app-navbar',
                        template: "<nav>\r\n  <a *ngFor=\"let item of items\" [routerLink]=\"item.url\" routerLinkActive=\"active\">{{item.nombre}}</a>\r\n</nav>",
                        styles: [":host{border:0 solid #e1e1e1;border-bottom-width:1px;display:block;height:48px;padding:0 16px}nav a{color:#8f8f8f;font-size:14px;font-weight:500;line-height:48px;margin-right:20px;text-decoration:none;vertical-align:middle;cursor:pointer}nav a.router-link-active{color:#106cc8}"]
                    }] }
        ];
        /** @nocollapse */
        NavbarComponent.ctorParameters = function () { return []; };
        NavbarComponent.propDecorators = {
            items: [{ type: core.Input }]
        };
        return NavbarComponent;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var NavbarModule = /** @class */ (function () {
        function NavbarModule() {
        }
        NavbarModule.decorators = [
            { type: core.NgModule, args: [{
                        declarations: [NavbarComponent],
                        imports: [platformBrowser.BrowserModule, common.CommonModule, router.RouterModule
                        ],
                        exports: [NavbarComponent]
                    },] }
        ];
        return NavbarModule;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var Item = /** @class */ (function () {
        function Item() {
        }
        return Item;
    }());

    exports.Item = Item;
    exports.NavbarComponent = NavbarComponent;
    exports.NavbarModule = NavbarModule;

    Object.defineProperty(exports, '__esModule', { value: true });

}));
//# sourceMappingURL=ceiba-navbar.umd.js.map
