export declare class Item {
    url: string;
    nombre: string;
}
