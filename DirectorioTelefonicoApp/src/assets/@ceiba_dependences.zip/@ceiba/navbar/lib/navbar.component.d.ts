import { OnInit } from '@angular/core';
import { Item } from './modelo/item';
export declare class NavbarComponent implements OnInit {
    items: Item[];
    constructor();
    ngOnInit(): void;
}
