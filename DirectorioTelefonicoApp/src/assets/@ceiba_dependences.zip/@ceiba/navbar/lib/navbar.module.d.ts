export declare class NavbarModule {
}
