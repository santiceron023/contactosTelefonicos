"use strict";

/**
 * onloadstart / 'loadstart'
 * onprogress / 'progress'
 * onabort / 'abort'
 * onerror / 'error'
 * onload / 'load'
 * ontimeout / 'timeout'
 * onloadend / 'loadend'
 * onreadystatechange / 'readystatechange'
 */
var EB = EventBus || { addEventListener: function(){}, dispatch: function(){} };

function log(){ console.log.apply(console, arguments); }

var EVENTS = {
    ABORT: "abort",
    TIMEOUT: "timeout",
    LOADEND: "loadend",
    ACTIVE_PLG: "activePlugin",
    CACHE_LOAD: "loadFromCache",
    CACHE_SAVE: "saveCache",
    PCACHE_LOAD: "loadFromPCache",
    PCACHE_SAVE: "savePCache",

    LOAD_FINISH_NOTOK: "finishNotOk"
};

(function () {
    var DAY_IN_MILIS = 86400000; // 1000 * 240;//
    var NUM_DAYS = DAY_IN_MILIS * 2;
    var EVENT_LOAD = "loadend";
    var EVENT_ERROR = "error";
    var plugins = {};
    var xhr = XMLHttpRequest;
    var origLstn = xhr.prototype.addEventListener;
    var origSend = xhr.prototype.send;
    var origOpen = xhr.prototype.open;
    var origAbor = xhr.prototype.abort;
    var origHead = xhr.prototype.setRequestHeader;

    function processEventListeners(xhrInst, name, args){
        if( xhrInst.xhrEvents ){
            var events = xhrInst.xhrEvents[name];

            //log('processEventListeners', name);
            if( events ){
                events.forEach(function(event){
                    event.apply(xhrInst, args);
                });
            }
        }
    }

    (function(){
        /**
         * Plugin: Retries
         */
        var MAX_RETRIES = 3;
        var TIMEOUT = 3000;
        
        function Retries(xhr){
            //log('new retries', xhr);
            var retries = 1;
            var savedTimeout = this.ontimeout;

            xhr.timeout = TIMEOUT;
            xhr.ontimeout = function(){
                if( retries < MAX_RETRIES ){
                    log('retry', retries);
                    retries++;
                    xhr.abort();
                    
                    xhr.open.apply(xhr, xhr.saved.openArgs);
                    xhr.send.apply(xhr, xhr.saved.sendArgs);
                }else{
                    if( savedTimeout ){
                        savedTimeout.apply(xhr, arguments);
                    }
                }
            };
        }

        /**
         * Plugin: Persisted Cache
         */
        var xhrCache = {};

        function Db(){
            var win = window;
            var db = null;
            
            if (!win.indexedDB) {
                log("Your browser doesn't support a stable version of IndexedDB.");
                
                this.load = function(key, fnResult){ 
                    var result = xhrCache[key];
                    fnResult(result); 
                };
                this.deleteAndSave = function(key, value){
                    xhrCache[key] = value;
                };
            }else{
                var fnLogSuccess = function(){ /*log("success");*/ };
                var fnLogError = function(){ log("error", arguments); };
                var request = win.indexedDB.open("CacheDatabase", 2);
                
                request.onerror = function(event) {
                    log("Why didn't you allow my web app to use IndexedDB?!");
                };
                
                request.onupgradeneeded = function(event) {                
                    db = event.target.result;
                    var objectStore = db.createObjectStore("xhr-cache", { keyPath: "id" });
                };
                
                request.onsuccess = function(event) {
                    log("database instantiated");
                    db = event.target.result;
                };

                this.save = function(key, value){
                    var request = db.transaction(["xhr-cache"], "readwrite")
                        .objectStore("xhr-cache")
                        .add({ id: key, value: value });    

                    request.onsuccess = fnLogSuccess;
                    request.onerror = fnLogError;
                };

                this.load = function(key, fnResult){
                    var transaction = db.transaction(["xhr-cache"]);
                    var objectStore = transaction.objectStore("xhr-cache");
                    var request = objectStore.get(key);
                    
                    request.onerror = fnLogError;
                    request.onsuccess = function(event) {
                        fnResult(request.result);
                    };
                };

                this.delete = function(key, fnSuccess){
                    var transaction = db.transaction(["xhr-cache"], "readwrite");
                    var objectStore = transaction.objectStore("xhr-cache");
                    var request = objectStore.delete(key);
                    
                    request.onerror = fnLogError;
                    request.onsuccess = function(event) {
                        //fnResult(request.result);
                        if( fnSuccess ){
                            fnSuccess(event);
                        }
                    };
                };

                this.deleteAndSave = function(key, value, fnSuccess){
                    var thiz = this;

                    this.load(key, function(reg){
                        if( reg ){
                            thiz.delete(key, function(){
                                thiz.save(key, value);
                            });
                        }else{
                            thiz.save(key, value);
                        }
                    });
                };
            }
        }

        var cacheDb = new Db();

        function PersistedCache(xhr){
            //log('new cache', xhr);
            var xhrOpen = xhr.open;
            var xhrSend = xhr.send;

            var isSupported = function(){
                var result = "-={0}=-";
                var x = new XMLHttpRequest();

                Object.defineProperty(x, 'response', { get: function(){ return result; } });
                return x.response == result;
            }();

            if( !isSupported ){
                log('this browser not support Object.defineProperty this plugin is disabled');
            }else{
                var fnSaveCache = function(){ 
                    if( this.readyState == 4 && this.status == 200 ){
                        //log('save cache key', this.cacheKey, arguments);
                        EB.dispatch(EVENTS.PCACHE_SAVE, this.cacheKey, arguments);

                        var preferResponseText = !xhr.responseType;

                        cacheDb.deleteAndSave(this.cacheKey, {
                            time: new Date().getTime() + NUM_DAYS,
                            response: xhr.response,
                            responseType: xhr.responseType,
                            responseText: preferResponseText ? xhr.responseText : null,
                            responseXML: xhr.responseType == 'xml' ? xhr.responseXML : null
                        });
                    }
                };

                origLstn.apply(xhr, [EVENT_LOAD, fnSaveCache, false]);

                xhr.send = function(){
                    this.cacheKey = JSON.stringify(xhr.saved.openArgs);                

                    cacheDb.load(this.cacheKey, function(reg){
                        var t = new Date().getTime();

                        if(reg && reg.value.time > t){ // != null
                            //log(reg.value.time, t, reg.value.time < t);
                            
                            var result = reg.value;
                            var args = new ProgressEvent(EVENT_LOAD, {
                                status: 200,
                                response: result.response
                            });

                            //log('load from cache', xhr.cacheKey);
                            EB.dispatch(EVENTS.PCACHE_LOAD, { key: xhr.cacheKey });

                            Object.defineProperty(xhr, 'readyState', { get: function(){ return 4; } });
                            Object.defineProperty(xhr, 'statusText', { get: function(){ return "OK"; } });
                            Object.defineProperty(xhr, 'response', { get: function(){ return result.response; } });
                            Object.defineProperty(xhr, 'responseType', { get: function(){ return result.responseType; } });
                            Object.defineProperty(xhr, 'responseText', { get: function(){ return result.responseText; } });

                            processEventListeners(xhr, 'load', args);
                            processEventListeners(xhr, EVENT_LOAD, args);

                            if( xhr.onreadystatechange ){
                                xhr.onreadystatechange.apply(xhr);
                            }

                            xhr.abort();
                        }else{
                            xhrSend.apply(xhr, arguments);
                        }
                    });
                };
            }
        }

        plugins = {
            retries: Retries,
            cache: PersistedCache,
            pcache: PersistedCache
        };
    })();

    xhr.prototype.setRequestHeader = function(){
        //log('setRequestHeader', arguments);

        if( arguments[0] == 'xhr-plugin' && plugins[arguments[1]] !== null ){
            var plgs = arguments[1].split(',');

            for(var index=0; index<plgs.length; index++){
                var plugin = plgs[index];

                if( plugins[plugin] ){
                    var pluginClass = plugins[plugin];

                    this.plugins = this.plugins || [];
                    this.plugins.push( new pluginClass(this) );
                }
            }

            //log('active plugins', this.plugins, plgs);
            EB.dispatch(EVENTS.ACTIVE_PLG, this.plugins, plgs);
        }else if( arguments[0] == 'xhr-name'){            
            this.xhrName = arguments[1];
        }else{
            origHead.apply(this, arguments);
        }
    };

    xhr.prototype.addEventListener = function(){
        //log('addEventListener', arguments);
        this.xhrEvents = this.xhrEvents || {};

        var event = arguments[0];

        if( !this.xhrEvents[event] ){
            this.xhrEvents[event] = [];            

            origLstn.apply(this, [event, function(){
                processEventListeners(this, event, arguments);
            }, false]);
        }

        this.xhrEvents[event].push(arguments[1]);
    };

    xhr.prototype.open = function () {
        if( !this.saved ){
            this.saved = {
                openArgs: null,
                sendArgs: null,
                statics: {
                    ini: null,
                    end: null,
                    state: null
                }
            };
        }
        
        this.saved.openArgs = arguments;

        origOpen.apply(this, arguments);
    };

    xhr.prototype.send = function () {  
        this.saved.sendArgs = arguments;
        this.saved.statics.ini = new Date().getTime();

        this.registerLoadEnd();
        this.registerTimeout();

        origSend.apply(this, arguments);
    };

    xhr.prototype.registerLoadEnd = function(){
        origLstn.apply(this, [EVENT_LOAD, function(){
            if( this.readyState == 4 ){
                if( this.status == 200 ){
                    this.saved.statics.end = new Date().getTime();
                    this.saved.statics.dif = this.saved.statics.end - this.saved.statics.ini;

                    EB.dispatch(EVENTS.LOADEND, this.saved);
                }else{
                    EB.dispatch(EVENTS.LOAD_FINISH_NOTOK, this);
                }
            }
        }, false]);

        origLstn.apply(this, [EVENT_ERROR, function(){
            if( this.readyState == 4 ){
                EB.dispatch(EVENTS.LOAD_FINISH_NOTOK, this);
            }
        }, false]);
    };

    xhr.prototype.registerTimeout = function(){
        this.isregistered = this.isregistered || false;

        if(!this.isregistered){
            this.isregistered = true;

            var tt = this.ontimeout || function(){ log('no-ontimeout'); };

            var mytimeout = function(e){
                this.saved = (this.saved !== "undefined") ? this.saved : { statics: { state: null } };
                this.saved.statics.state = EVENTS.TIMEOUT;

                EB.dispatch(EVENTS.TIMEOUT, this.saved);
                tt();
            };

            this.ontimeout = mytimeout;
        }
    };

    xhr.prototype.abort = function(){
        this.saved.statics.state = EVENTS.ABORT;
        EB.dispatch(EVENTS.ABORT, this.saved);
        origAbor.apply(this, arguments);
    };

})();

/*function fnLog(event) {
    log("event", event);
}

EB.addEventListener(EVENTS.TIMEOUT, fnLog);
//EB.addEventListener("loadend", myFunction);
EB.addEventListener(EVENTS.ABORT, fnLog);
EB.addEventListener(EVENTS.PCACHE_LOAD, fnLog);
EB.addEventListener(EVENTS.PCACHE_SAVE, fnLog);

EB.addEventListener(EVENTS.LOAD_FINISH_NOTOK, function(event){ 
    console.log("finish error:", event);
 });*/